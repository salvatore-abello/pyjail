#!/bin/bash

python chall.py