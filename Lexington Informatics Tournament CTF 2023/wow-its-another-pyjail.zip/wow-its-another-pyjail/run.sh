#!/bin/bash

cd /home/user
python3.10 jail.py
