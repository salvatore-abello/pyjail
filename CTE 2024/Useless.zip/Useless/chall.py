#!/usr/bin/env python3
import sys
import ast


def _clear_module(module, _dir, _delattr):
    for obj in _dir(module):
        _delattr(module, obj)

def _prepare_sandbox():
    unsafe_modules = ["builtins", "os", "sys", "__main__"]
    _sys = sys

    _dir = dir
    _delattr = delattr
    _sys_modules = dict(_sys.modules)
    _sys.modules.clear()

    for unsafe_module in unsafe_modules:
        _clear_module(_sys_modules[unsafe_module], _dir, _delattr)

def _check(parsed):
    for n in ast.walk(parsed):
        match type(n):
            case ast.Name:
                if n.id.startswith("_") or n.id.endswith("_"):
                    sys.exit(1)

            case ast.Attribute:
                if n.attr.startswith("_") or n.attr.endswith("_"):
                    sys.exit(1)

            case ast.Constant:
                sys.exit(1)

            case ast.Expr:
                _check(n.value)

            # :eyes:
            case ast.Lambda:
                sys.exit(1)

def _main():
    _code = input(">>> ")
    _eval = eval
    _parsed = ast.parse(_code)

    _check(_parsed)

    if not _code.isascii():
        sys.exit(1)

    _prepare_sandbox()
    _eval(_code, {"__builtins__": {}}, {})


if __name__ == "__main__":
    _main()
