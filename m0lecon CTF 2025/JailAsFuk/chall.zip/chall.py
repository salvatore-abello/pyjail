#!/usr/bin/env python3
import ast
import builtins
import sys
import traceback


og_str = builtins.str


class my_str(str):
    def __add__(self, other):
        if isinstance(other, int):
            return my_str(super().__add__(chr(other)))
        return my_str(super().__add__(other))

    def __radd__(self, other):
        if isinstance(other, int):
            return other.__add__(self.__int__())
        return my_str(super().__radd__(other))

    def __int__(self):
        return int.from_bytes(self.encode(), "big", signed=True)

    def __pos__(self):
        if len(self):
            return self.__int__()
        return 0

    def __call__(self, *args, **kwargs):
        if len(self):
            tree = ast.parse(self, __name__, "eval")
            ast.fix_missing_locations(tree)
            return eval(
                compile(
                    tree,
                    filename=__name__,
                    mode="eval",
                    dont_inherit=True,
                ),
                {
                    "__name__": __name__,
                    "__builtins__": __import__("builtins")},
                {
                    "args": args,
                    "kwargs": kwargs,
                },
            )
        return None


class StringTransformer(ast.NodeTransformer):
    def visit_Constant(self, node):
        if isinstance(node.value, og_str):
            return ast.Call(
                func=ast.Name(id="str", ctx=ast.Load()),
                args=[ast.Constant(value=node.value)],
                keywords=[]
            )
        return node


allowed_chars = set('"()+')


def run(source, mode="exec", check=True):
    if check:
        assert source.isascii() and len(source) < 32000 and len(set(source) - allowed_chars) == 0,  set(source) - allowed_chars
    tree = ast.parse(source, __name__, mode)
    my_tree = StringTransformer().visit(tree)
    ast.fix_missing_locations(my_tree)
    my_builtins = __import__("builtins")
    runner = getattr(my_builtins, mode)
    my_builtins.str = my_str
    return runner(
        compile(
            my_tree,
            filename=__name__,
            mode=mode,
            dont_inherit=True,
        ),
        {
            "__name__": __name__,
            "__builtins__": my_builtins},
        {},
    )


if __name__ == "__main__":
    try:
        print("Show me what you've got!")
        i = input("> ")
        if i.isascii() and len(i) < 32000 and len(set(i) - allowed_chars) == 0:
            print(run(i, mode="eval"))
        else:
            print("I'll only run special pyfuck. Sorry.")
    except Exception as e:
        if not isinstance(e, AssertionError):
            traceback.print_exc(file=sys.stderr)
        print("Seems like there is something wrong here...")
